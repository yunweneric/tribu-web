import DataTable, { TableColumn } from 'react-data-table-component';
export interface DataRow {
  title: string;
  director: string;
  year: string;
}
